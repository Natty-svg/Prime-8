# PRIME 8 Website Builder

A responsive visual website builder starter.

## Included
- Responsive editor
- Element insertion and drag/drop
- Templates
- Live preview
- Desktop/tablet/mobile modes
- Text and background editing
- Local save
- Undo/redo
- HTML export
- GitHub Pages workflow

## Publish
1. Create a GitHub repository named `prime-8`.
2. Upload all files, including `.github/workflows/deploy.yml`.
3. In Settings > Pages, choose GitHub Actions.
4. Push to the `main` branch.
